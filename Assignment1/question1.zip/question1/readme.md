-compile command
g++ question1.cpp

-executed commands
./a.out top14.doc NSFNET_100.doc routingtable  forwardingtable pathfile -flag dist -p 0
./a.out top14.doc NSFNET_100.doc routingtable  forwardingtable pathfile -flag dist -p 1
./a.out top14.doc NSFNET_100.doc routingtable  forwardingtable pathfile -flag path -p 0
./a.out top14.doc NSFNET_100.doc routingtable  forwardingtable pathfile -flag path -p 1

./a.out top24.doc ARPANET_100.doc routingtable  forwardingtable pathfile -flag dist -p 0
./a.out top24.doc ARPANET_100.doc routingtable  forwardingtable pathfile -flag dist -p 1
./a.out top24.doc ARPANET_100.doc routingtable  forwardingtable pathfile -flag path -p 0
./a.out top24.doc ARPANET_100.doc routingtable  forwardingtable pathfile -flag path -p 1